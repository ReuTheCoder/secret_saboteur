import { useState, useCallback } from "react";
import GameLobby from "@/components/game/GameLobby";
import PlayerNamesScreen from "@/components/game/PlayerNamesScreen";
import RoleCard, { PlayerRole } from "@/components/game/RoleCard";
import DiscussionScreen from "@/components/game/DiscussionScreen";
import GuesserScreen from "@/components/game/GuesserScreen";
import ResultsScreen from "@/components/game/ResultsScreen";

type GamePhase = "lobby" | "enterNames" | "roleAssignment" | "discussion" | "guess" | "results";

interface GameState {
  playerCount: number;
  playerNames: string[];
  currentPlayerIndex: number;
  assignedNumber: number;
  guesserIndex: number;
  saboteurIndex: number;
  guessedNumber: number | null;
  prompt: {
    title: string;
    lowLabel: string;
    highLabel: string;
  };
}

const SAMPLE_PROMPTS = [
  { title: "Reasons to Call 911", lowLabel: "Reasonable", highLabel: "Ridiculous" },
  { title: "Places to Nap", lowLabel: "Very Comfortable", highLabel: "Very Uncomfortable" },
  { title: "Cool for a High-Schooler", lowLabel: "Not Cool", highLabel: "Cool" },
  { title: "Things to Discover in Your Pocket", lowLabel: "Exciting", highLabel: "Not Exciting" },
  { title: "Last Words", lowLabel: "Forgettable", highLabel: "Memorable" },
  { title: "Movies", lowLabel: "Relaxing", highLabel: "Intense" },
  { title: "TV Shows", lowLabel: "Serious", highLabel: "Relaxing" },
  { title: "Food to Eat at 7am", lowLabel: "Good", highLabel: "Bad" },
  { title: "Places to Go for Summer Vacation", lowLabel: "Worst", highLabel: "Best" },
  { title: "Times to Do Homework", lowLabel: "Good", highLabel: "Bad" },
  { title: "Reasons to Be Late", lowLabel: "Understandable", highLabel: "Ridiculous" },
  { title: "Excuses to Leave a Party Early", lowLabel: "Believable", highLabel: "Unbelievable" },
  { title: "Things You Should Never Google", lowLabel: "Harmless", highLabel: "Traumatizing" },
  { title: "Things That Ruin Your Day", lowLabel: "Minor", highLabel: "Devastating" },
  { title: "Reasons to Cancel Plans", lowLabel: "Acceptable", highLabel: "Unforgivable" },
  { title: "School Supplies", lowLabel: "Useless", highLabel: "Essential" },
  { title: "Ways to Get Suspended", lowLabel: "Understandable", highLabel: "Stupid" },
  { title: "Things to Do in Class When Bored", lowLabel: "Quiet", highLabel: "Disruptive" },
  { title: "Clubs to Join", lowLabel: "Boring", highLabel: "Fun" },
  { title: "Times to Laugh", lowLabel: "Appropriate", highLabel: "Inappropriate" },
  { title: "Things to Accidentally Text Your Teacher", lowLabel: "Fine", highLabel: "Horrifying" },
  { title: "Icebreakers", lowLabel: "Boring", highLabel: "Painfully Awkward" },
  { title: "Reasons Someone Stops Replying", lowLabel: "Reasonable", highLabel: "Suspicious" },
  { title: "Foods to Bring to a Potluck", lowLabel: "Welcomed", highLabel: "Questioned" },
  { title: "Midnight Snacks", lowLabel: "Normal", highLabel: "Concerning" },
  { title: "Foods to Eat in Class", lowLabel: "Stealthy", highLabel: "Obvious" },
  { title: "Foods That Should Never Be Microwaved", lowLabel: "Slightly Bad", highLabel: "A War Crime" },
  { title: "Restaurant Orders", lowLabel: "Safe", highLabel: "Risky" },
  { title: "Places to Sit", lowLabel: "Comfortable", highLabel: "Miserable" },
  { title: "Sounds to Fall Asleep To", lowLabel: "Soothing", highLabel: "Unbearable" },
  { title: "Clothes to Sleep In", lowLabel: "Comfy", highLabel: "A Mistake" },
  { title: "Weather to Walk In", lowLabel: "Pleasant", highLabel: "Brutal" },
  { title: "Times to Wake Up", lowLabel: "Ideal", highLabel: "Cruel" },
  { title: "Things You'd Yell in a Library", lowLabel: "Quiet", highLabel: "Unacceptable" },
  { title: "Places to Lose Your Phone", lowLabel: "Recoverable", highLabel: "Hopeless" },
  { title: "Ways to Get Famous", lowLabel: "Respectable", highLabel: "Infamous" },
  { title: "Things to Wear to a Funeral", lowLabel: "Appropriate", highLabel: "Offensive" },
  { title: "Reasons Someone Gets Kicked Out of a Store", lowLabel: "Accidental", highLabel: "Deserved" },
  { title: "Lies", lowLabel: "Believable", highLabel: "Terrible" },
  { title: "Secrets", lowLabel: "Harmless", highLabel: "Life-Ruining" },
  { title: "Things You Should Never Say Out Loud", lowLabel: "Harmless", highLabel: "Disastrous" },
  { title: "Things That Would Ruin a First Impression", lowLabel: "Minor", highLabel: "Unforgettable" },
  { title: "Things to Scream in Public", lowLabel: "Confusing", highLabel: "Arrest-Worthy" },
  { title: "Ways to Embarrass Yourself", lowLabel: "Subtle", highLabel: "Legendary" },
  { title: "Things You Regret Immediately", lowLabel: "Mild", highLabel: "Life-Altering" },
  { title: "Bad Ideas", lowLabel: "Questionable", highLabel: "Catastrophic" },
  { title: "Things That Make a Situation Awkward", lowLabel: "Slightly Awkward", highLabel: "Unbearable" },
  { title: "Times to Raise Your Hand in Class", lowLabel: "Appropriate", highLabel: "Unnecessary" },
  { title: "Ways to Get Detention", lowLabel: "Understandable", highLabel: "Stupid" },
  { title: "School Rules", lowLabel: "Fair", highLabel: "Ridiculous" },
  { title: "Teachers' Habits", lowLabel: "Normal", highLabel: "Unhinged" },
  { title: "School Lunches", lowLabel: "Edible", highLabel: "Suspicious" },
  { title: "Excuses for Missing Homework", lowLabel: "Reasonable", highLabel: "Unbelievable" },
  { title: "Places to Sit on the School Bus", lowLabel: "Ideal", highLabel: "Cursed" },
  { title: "Group Project Roles", lowLabel: "Helpful", highLabel: "Useless" },
  { title: "Things to Forget on Exam Day", lowLabel: "Inconvenient", highLabel: "Disastrous" },
  { title: "Things to Say on a First Date", lowLabel: "Safe", highLabel: "Disastrous" },
  { title: "Compliments", lowLabel: "Nice", highLabel: "Creepy" },
  { title: "Questions to Ask a Stranger", lowLabel: "Normal", highLabel: "Invasive" },
  { title: "Things to Say in an Argument", lowLabel: "Calm", highLabel: "Nuclear" },
  { title: "Ways to End a Conversation", lowLabel: "Polite", highLabel: "Rude" },
  { title: "Social Mistakes", lowLabel: "Forgivable", highLabel: "Unforgettable" },
  { title: "Foods to Eat While Driving", lowLabel: "Manageable", highLabel: "Dangerous" },
  { title: "Snacks to Share", lowLabel: "Generous", highLabel: "Selfish" },
  { title: "Weird Food Combinations", lowLabel: "Acceptable", highLabel: "Criminal" },
  { title: "Drinks to Spill on Yourself", lowLabel: "Harmless", highLabel: "Tragic" },
  { title: "Places to Wait in Line", lowLabel: "Tolerable", highLabel: "Torture" },
  { title: "Seats on an Airplane", lowLabel: "Amazing", highLabel: "Awful" },
  { title: "Places to Lose Your Keys", lowLabel: "Recoverable", highLabel: "Hopeless" },
  { title: "Things to Step on Barefoot", lowLabel: "Annoying", highLabel: "Painful" },
  { title: "Movie Genres", lowLabel: "Boring", highLabel: "Exciting" },
  { title: "Songs to Play at a Party", lowLabel: "A Vibe", highLabel: "A Mood Killer" },
  { title: "Songs to Wake Up To", lowLabel: "Gentle", highLabel: "Aggressive" },
  { title: "Games to Play with Friends", lowLabel: "Chill", highLabel: "Chaotic" },
  { title: "YouTube Videos", lowLabel: "Informative", highLabel: "Unhinged" },
  { title: "Shows to Binge", lowLabel: "Light", highLabel: "Emotionally Draining" },
  { title: "Movies to Watch with Parents", lowLabel: "Safe", highLabel: "Awkward" },
  { title: "Trailers", lowLabel: "Boring", highLabel: "Hype" },
  { title: "Places to Visit with Friends", lowLabel: "Chill", highLabel: "Chaotic" },
  { title: "Places to Get Lost", lowLabel: "Manageable", highLabel: "Terrifying" },
  { title: "Places to Take a First Date", lowLabel: "Safe", highLabel: "Risky" },
  { title: "Places to Study", lowLabel: "Productive", highLabel: "Distracting" },
  { title: "Places to Cry", lowLabel: "Private", highLabel: "Public" },
  { title: "Places to Hide Something", lowLabel: "Obvious", highLabel: "Impossible to Find" },
  { title: "Places to Be During a Storm", lowLabel: "Safe", highLabel: "Dangerous" },
  { title: "Places to Forget Your Wallet", lowLabel: "Annoying", highLabel: "Disastrous" },
  { title: "Places to Run Into Someone You Know", lowLabel: "Fine", highLabel: "Awkward" },
  { title: "Things You'd Lie About", lowLabel: "Small", highLabel: "Insane" },
  { title: "Things to Forget During a Presentation", lowLabel: "Awkward", highLabel: "Catastrophic" },
  { title: "Ways to Lose a Friendship", lowLabel: "Slow", highLabel: "Instant" },
  { title: "Things Found Under a Bed", lowLabel: "Expected", highLabel: "Disturbing" },
  { title: "Things to Name a Pet", lowLabel: "Cute", highLabel: "Unhinged" },
  { title: "Superpowers", lowLabel: "Useless", highLabel: "Overpowered" },
  { title: "Things You'd Frame on Your Wall", lowLabel: "Normal", highLabel: "Questionable" },
  { title: "Items to Bring on a Deserted Island", lowLabel: "Smart", highLabel: "Pointless" },
  { title: "Things to Overhear", lowLabel: "Boring", highLabel: "Shocking" },
  { title: "Things You'd Want Erased from History", lowLabel: "Minor", highLabel: "Major" },
  { title: "Things to Be Remembered For", lowLabel: "Forgettable", highLabel: "Legendary" },
  { title: "Times to Take a Nap", lowLabel: "Perfect", highLabel: "Disastrous" },
  { title: "Times to Text Someone", lowLabel: "Appropriate", highLabel: "Suspicious" },
  { title: "Times to Tell the Truth", lowLabel: "Safe", highLabel: "Dangerous" },
  { title: "Times to Lie", lowLabel: "Understandable", highLabel: "Terrible" },
  { title: "Times to Show Up Early", lowLabel: "Impressive", highLabel: "Awkward" },
  { title: "Times to Eat Dinner", lowLabel: "Ideal", highLabel: "Unhinged" },
  { title: "Times to Ask a Question", lowLabel: "Helpful", highLabel: "Annoying" },
  { title: "Times to Stay Silent", lowLabel: "Smart", highLabel: "Suspicious" },
  { title: "Times to Leave", lowLabel: "Polite", highLabel: "Dramatic" },
  { title: "Things to Forget at Home", lowLabel: "Inconvenient", highLabel: "Disastrous" },
  { title: "Ways to Apologize", lowLabel: "Sincere", highLabel: "Insulting" },
  { title: "Things to Spend Money On", lowLabel: "Worth It", highLabel: "A Waste" },
];

function getRandomPrompt() {
  return SAMPLE_PROMPTS[Math.floor(Math.random() * SAMPLE_PROMPTS.length)];
}

function getRandomNumber(): number {
  return Math.floor(Math.random() * 10) + 1;
}

function getRandomIndices(playerCount: number): { guesser: number; saboteur: number } {
  const guesser = Math.floor(Math.random() * playerCount);
  let saboteur = Math.floor(Math.random() * playerCount);
  while (saboteur === guesser) {
    saboteur = Math.floor(Math.random() * playerCount);
  }
  return { guesser, saboteur };
}

export default function Game() {
  const [phase, setPhase] = useState<GamePhase>("lobby");
  const [gameState, setGameState] = useState<GameState>({
    playerCount: 0,
    playerNames: [],
    currentPlayerIndex: 0,
    assignedNumber: 0,
    guesserIndex: -1,
    saboteurIndex: -1,
    guessedNumber: null,
    prompt: SAMPLE_PROMPTS[0],
  });

  const handleStartGame = useCallback((playerCount: number) => {
    setGameState((prev) => ({
      ...prev,
      playerCount,
      playerNames: [],
    }));
    setPhase("enterNames");
  }, []);

  const handleSubmitNames = useCallback((names: string[]) => {
    const { guesser, saboteur } = getRandomIndices(gameState.playerCount);
    setGameState((prev) => ({
      ...prev,
      playerNames: names,
      currentPlayerIndex: 0,
      assignedNumber: getRandomNumber(),
      guesserIndex: guesser,
      saboteurIndex: saboteur,
      guessedNumber: null,
      prompt: getRandomPrompt(),
    }));
    setPhase("roleAssignment");
  }, [gameState.playerCount]);

  const handleNextPlayer = useCallback(() => {
    const nextIndex = gameState.currentPlayerIndex + 1;
    if (nextIndex >= gameState.playerCount) {
      setPhase("discussion");
    } else {
      setGameState((prev) => ({
        ...prev,
        currentPlayerIndex: nextIndex,
      }));
    }
  }, [gameState.currentPlayerIndex, gameState.playerCount]);

  const handleContinueToGuess = useCallback(() => {
    setPhase("guess");
  }, []);

  const handleSubmitGuess = useCallback((guess: number) => {
    setGameState((prev) => ({
      ...prev,
      guessedNumber: guess,
    }));
    setPhase("results");
  }, []);

  const handlePlayAgain = useCallback(() => {
    const { guesser, saboteur } = getRandomIndices(gameState.playerCount);
    setGameState((prev) => ({
      ...prev,
      currentPlayerIndex: 0,
      assignedNumber: getRandomNumber(),
      guesserIndex: guesser,
      saboteurIndex: saboteur,
      guessedNumber: null,
      prompt: getRandomPrompt(),
    }));
    setPhase("roleAssignment");
  }, [gameState.playerCount]);

  const handleNewGame = useCallback(() => {
    setPhase("lobby");
    setGameState({
      playerCount: 0,
      playerNames: [],
      currentPlayerIndex: 0,
      assignedNumber: 0,
      guesserIndex: -1,
      saboteurIndex: -1,
      guessedNumber: null,
      prompt: SAMPLE_PROMPTS[0],
    });
  }, []);

  const getPlayerRole = (playerIndex: number): PlayerRole => {
    if (playerIndex === gameState.guesserIndex) return "guesser";
    if (playerIndex === gameState.saboteurIndex) return "saboteur";
    return "teammate";
  };

  switch (phase) {
    case "lobby":
      return <GameLobby onStartGame={handleStartGame} />;
    
    case "enterNames":
      return (
        <PlayerNamesScreen
          playerCount={gameState.playerCount}
          onSubmitNames={handleSubmitNames}
        />
      );
    
    case "roleAssignment":
      return (
        <RoleCard
          playerName={gameState.playerNames[gameState.currentPlayerIndex]}
          role={getPlayerRole(gameState.currentPlayerIndex)}
          assignedNumber={gameState.assignedNumber}
          onNextPlayer={handleNextPlayer}
          isLastPlayer={gameState.currentPlayerIndex === gameState.playerCount - 1}
        />
      );
    
    case "discussion":
      return (
        <DiscussionScreen
          prompt={gameState.prompt}
          onContinueToGuess={handleContinueToGuess}
        />
      );
    
    case "guess":
      return (
        <GuesserScreen
          prompt={gameState.prompt}
          onSubmitGuess={handleSubmitGuess}
        />
      );
    
    case "results":
      return (
        <ResultsScreen
          correctNumber={gameState.assignedNumber}
          guessedNumber={gameState.guessedNumber!}
          saboteurName={gameState.playerNames[gameState.saboteurIndex]}
          onPlayAgain={handlePlayAgain}
          onNewGame={handleNewGame}
        />
      );
    
    default:
      return <GameLobby onStartGame={handleStartGame} />;
  }
}
