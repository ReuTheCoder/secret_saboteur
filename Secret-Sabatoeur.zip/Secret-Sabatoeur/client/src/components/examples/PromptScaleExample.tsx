import PromptScale from "../game/PromptScale";

export default function PromptScaleExample() {
  return (
    <div className="p-8 bg-background">
      <PromptScale
        title="Impact on Your Energy Level"
        lowLabel="Puts You to Sleep"
        highLabel="Keeps You Awake"
        highlightNumber={7}
      />
    </div>
  );
}
