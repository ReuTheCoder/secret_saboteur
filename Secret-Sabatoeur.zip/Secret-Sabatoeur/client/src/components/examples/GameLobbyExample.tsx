import GameLobby from "../game/GameLobby";

export default function GameLobbyExample() {
  return (
    <GameLobby
      onStartGame={(count) => console.log(`Starting game with ${count} players`)}
    />
  );
}
