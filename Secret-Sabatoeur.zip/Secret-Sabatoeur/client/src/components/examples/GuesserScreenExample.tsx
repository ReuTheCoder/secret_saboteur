import GuesserScreen from "../game/GuesserScreen";

export default function GuesserScreenExample() {
  return (
    <GuesserScreen
      prompt={{
        title: "Impact on Your Energy Level",
        lowLabel: "Puts You to Sleep",
        highLabel: "Keeps You Awake",
      }}
      onSubmitGuess={(guess) => console.log(`Guessed: ${guess}`)}
    />
  );
}
