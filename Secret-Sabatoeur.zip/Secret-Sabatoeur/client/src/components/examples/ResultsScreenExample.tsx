import ResultsScreen from "../game/ResultsScreen";

export default function ResultsScreenExample() {
  return (
    <ResultsScreen
      correctNumber={7}
      guessedNumber={6}
      saboteurName="Jordan"
      onPlayAgain={() => console.log("Play again")}
      onNewGame={() => console.log("New game")}
    />
  );
}
