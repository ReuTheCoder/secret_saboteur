import DiscussionScreen from "../game/DiscussionScreen";

export default function DiscussionScreenExample() {
  return (
    <DiscussionScreen
      prompt={{
        title: "Impact on Your Energy Level",
        lowLabel: "Puts You to Sleep",
        highLabel: "Keeps You Awake",
      }}
      onContinueToGuess={() => console.log("Continue to guess")}
    />
  );
}
