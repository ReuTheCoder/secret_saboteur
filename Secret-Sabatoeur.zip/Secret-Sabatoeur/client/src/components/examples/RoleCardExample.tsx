import RoleCard from "../game/RoleCard";

export default function RoleCardExample() {
  return (
    <RoleCard
      playerName="Alex"
      role="teammate"
      assignedNumber={7}
      onNextPlayer={() => console.log("Next player")}
      isLastPlayer={false}
    />
  );
}
