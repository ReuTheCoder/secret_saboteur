import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Users, ArrowRight } from "lucide-react";

interface PlayerNamesScreenProps {
  playerCount: number;
  onSubmitNames: (names: string[]) => void;
}

export default function PlayerNamesScreen({
  playerCount,
  onSubmitNames,
}: PlayerNamesScreenProps) {
  const [names, setNames] = useState<string[]>(
    Array.from({ length: playerCount }, (_, i) => `Player ${i + 1}`)
  );

  const handleNameChange = (index: number, value: string) => {
    const newNames = [...names];
    newNames[index] = value;
    setNames(newNames);
  };

  const allNamesFilled = names.every((name) => name.trim().length > 0);

  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center px-4 py-8">
      <div className="w-full max-w-md space-y-6">
        <div className="text-center space-y-2">
          <h1 className="text-3xl md:text-4xl font-bold text-foreground font-heading">
            Enter Player Names
          </h1>
          <div className="w-24 h-1 bg-primary mx-auto rounded-full" />
          <p className="text-muted-foreground text-lg mt-4">
            Who&apos;s playing today?
          </p>
        </div>

        <Card className="p-6 space-y-4">
          <div className="flex items-center gap-3 mb-4">
            <Users className="w-5 h-5 text-primary" />
            <span className="text-lg font-semibold text-foreground">
              {playerCount} Players
            </span>
          </div>

          <div className="space-y-3 max-h-[400px] overflow-y-auto">
            {names.map((name, index) => (
              <div key={index} className="flex items-center gap-3">
                <span className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center text-sm font-bold text-primary">
                  {index + 1}
                </span>
                <Input
                  value={name}
                  onChange={(e) => handleNameChange(index, e.target.value)}
                  placeholder={`Player ${index + 1}`}
                  className="flex-1"
                  data-testid={`input-player-name-${index + 1}`}
                />
              </div>
            ))}
          </div>
        </Card>

        <Button
          size="lg"
          className="w-full h-14 text-xl font-bold gap-2"
          disabled={!allNamesFilled}
          onClick={() => onSubmitNames(names)}
          data-testid="button-continue-names"
        >
          Continue
          <ArrowRight className="w-5 h-5" />
        </Button>
      </div>
    </div>
  );
}
