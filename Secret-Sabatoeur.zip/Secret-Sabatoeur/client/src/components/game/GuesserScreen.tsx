import { useState } from "react";
import { Button } from "@/components/ui/button";
import PromptScale from "./PromptScale";

interface GuesserScreenProps {
  prompt: {
    title: string;
    lowLabel: string;
    highLabel: string;
  };
  onSubmitGuess: (guess: number) => void;
}

export default function GuesserScreen({ prompt, onSubmitGuess }: GuesserScreenProps) {
  const [selectedNumber, setSelectedNumber] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center px-4 py-8">
      <div className="w-full max-w-lg space-y-8">
        <div className="text-center space-y-2">
          <h1 className="text-3xl md:text-4xl font-bold text-foreground font-heading">
            Guesser&apos;s Turn
          </h1>
          <p className="text-muted-foreground text-lg">
            Based on the discussion, guess the number!
          </p>
        </div>

        <PromptScale
          title={prompt.title}
          lowLabel={prompt.lowLabel}
          highLabel={prompt.highLabel}
        />

        <div className="space-y-4">
          <h3 className="text-xl font-semibold text-foreground text-center">
            What number was everyone given?
          </h3>
          
          <div className="grid grid-cols-5 gap-3">
            {Array.from({ length: 10 }, (_, i) => i + 1).map((num) => (
              <Button
                key={num}
                variant={selectedNumber === num ? "default" : "outline"}
                className={`h-16 text-2xl font-bold ${
                  selectedNumber === num ? "ring-2 ring-primary ring-offset-2" : ""
                }`}
                onClick={() => setSelectedNumber(num)}
                data-testid={`button-guess-${num}`}
              >
                {num}
              </Button>
            ))}
          </div>
        </div>

        <Button
          size="lg"
          className="w-full h-14 text-xl font-bold"
          disabled={selectedNumber === null}
          onClick={() => selectedNumber && onSubmitGuess(selectedNumber)}
          data-testid="button-submit-guess"
        >
          Submit Guess
        </Button>
      </div>
    </div>
  );
}
