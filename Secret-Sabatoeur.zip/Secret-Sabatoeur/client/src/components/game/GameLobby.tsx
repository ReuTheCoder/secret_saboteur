import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Users } from "lucide-react";

interface GameLobbyProps {
  onStartGame: (playerCount: number) => void;
}

export default function GameLobby({ onStartGame }: GameLobbyProps) {
  const [selectedCount, setSelectedCount] = useState<number | null>(null);
  const playerCounts = [3, 4, 5, 6, 7, 8, 9, 10];

  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center px-4 py-8">
      <div className="w-full max-w-md space-y-8">
        <div className="text-center space-y-2">
          <h1 className="text-4xl md:text-5xl font-bold text-foreground font-heading">
            Secret Saboteur
          </h1>
          <div className="w-24 h-1 bg-primary mx-auto rounded-full" />
          <p className="text-muted-foreground text-lg mt-4">
            A social deduction party game
          </p>
        </div>

        <Card className="p-6 space-y-6">
          <div className="flex items-center gap-3">
            <Users className="w-6 h-6 text-primary" />
            <h2 className="text-xl font-semibold text-foreground">
              How many players?
            </h2>
          </div>

          <div className="grid grid-cols-4 gap-3">
            {playerCounts.map((count) => (
              <Button
                key={count}
                variant={selectedCount === count ? "default" : "outline"}
                className={`h-14 text-xl font-bold ${
                  selectedCount === count ? "ring-2 ring-primary ring-offset-2" : ""
                }`}
                onClick={() => setSelectedCount(count)}
                data-testid={`button-player-count-${count}`}
              >
                {count}
              </Button>
            ))}
          </div>

          <p className="text-sm text-muted-foreground text-center">
            Select 3-10 players to start
          </p>
        </Card>

        <Button
          size="lg"
          className="w-full h-14 text-xl font-bold"
          disabled={selectedCount === null}
          onClick={() => selectedCount && onStartGame(selectedCount)}
          data-testid="button-start-game"
        >
          Start Game
        </Button>
      </div>
    </div>
  );
}
