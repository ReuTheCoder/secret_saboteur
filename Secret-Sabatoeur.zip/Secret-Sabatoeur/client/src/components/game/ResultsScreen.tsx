import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { motion } from "framer-motion";
import { Target, UserX, RotateCcw, Home } from "lucide-react";

interface ResultsScreenProps {
  correctNumber: number;
  guessedNumber: number;
  saboteurName: string;
  onPlayAgain: () => void;
  onNewGame: () => void;
}

export default function ResultsScreen({
  correctNumber,
  guessedNumber,
  saboteurName,
  onPlayAgain,
  onNewGame,
}: ResultsScreenProps) {
  const isCorrect = correctNumber === guessedNumber;

  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center px-4 py-8">
      <div className="w-full max-w-md space-y-8">
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.5, ease: "easeOut" }}
          className="text-center space-y-2"
        >
          <h1 className="text-4xl md:text-5xl font-bold text-foreground font-heading">
            Results
          </h1>
          <div className="w-24 h-1 bg-primary mx-auto rounded-full" />
        </motion.div>

        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2, duration: 0.5 }}
        >
          <Card className="p-6 space-y-6">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-full bg-primary/20 flex items-center justify-center">
                <Target className="w-7 h-7 text-primary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">The Number Was</p>
                <p className="text-4xl font-bold text-foreground">{correctNumber}</p>
              </div>
            </div>

            <div className="border-t border-border" />

            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-full bg-muted flex items-center justify-center">
                <span className="text-2xl font-bold text-muted-foreground">?</span>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Guesser Said</p>
                <p className={`text-4xl font-bold ${isCorrect ? "text-green-600" : "text-destructive"}`}>
                  {guessedNumber}
                </p>
              </div>
            </div>
          </Card>
        </motion.div>

        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.4, duration: 0.5 }}
        >
          <Card className="p-6 bg-black dark:bg-zinc-900 text-white">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-full bg-white/20 flex items-center justify-center">
                <UserX className="w-7 h-7" />
              </div>
              <div>
                <p className="text-sm opacity-75">The Saboteur Was</p>
                <p className="text-3xl font-bold">{saboteurName}</p>
              </div>
            </div>
          </Card>
        </motion.div>

        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.6, duration: 0.5 }}
          className="flex flex-col gap-3"
        >
          <Button
            size="lg"
            className="w-full h-14 text-xl font-bold gap-2"
            onClick={onPlayAgain}
            data-testid="button-play-again"
          >
            <RotateCcw className="w-5 h-5" />
            Play Again
          </Button>
          <Button
            size="lg"
            variant="outline"
            className="w-full h-14 text-xl font-bold gap-2"
            onClick={onNewGame}
            data-testid="button-new-game"
          >
            <Home className="w-5 h-5" />
            New Game
          </Button>
        </motion.div>
      </div>
    </div>
  );
}
