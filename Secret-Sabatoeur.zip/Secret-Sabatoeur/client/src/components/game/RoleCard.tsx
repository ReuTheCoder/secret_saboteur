import { useState } from "react";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { Eye, EyeOff } from "lucide-react";

export type PlayerRole = "teammate" | "guesser" | "saboteur";

interface RoleCardProps {
  playerName: string;
  role: PlayerRole;
  assignedNumber: number;
  onNextPlayer: () => void;
  isLastPlayer: boolean;
}

export default function RoleCard({
  playerName,
  role,
  assignedNumber,
  onNextPlayer,
  isLastPlayer,
}: RoleCardProps) {
  const [isFlipped, setIsFlipped] = useState(false);

  const getRoleDisplay = () => {
    switch (role) {
      case "guesser":
        return {
          title: "GUESSER",
          subtitle: "You must guess the number!",
          showNumber: false,
          bgColor: "bg-primary",
          textColor: "text-primary-foreground",
        };
      case "saboteur":
        return {
          title: "SABOTEUR",
          subtitle: "Mislead the group!",
          showNumber: true,
          bgColor: "bg-black dark:bg-zinc-900",
          textColor: "text-white",
        };
      case "teammate":
      default:
        return {
          title: "TEAMMATE",
          subtitle: "Help the Guesser!",
          showNumber: true,
          bgColor: "bg-primary",
          textColor: "text-primary-foreground",
        };
    }
  };

  const roleDisplay = getRoleDisplay();

  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center px-4 py-8">
      <div className="w-full max-w-md space-y-6">
        <div className="text-center">
          <p className="text-muted-foreground text-lg">Pass the device to</p>
          <h2 className="text-3xl font-bold text-foreground font-heading">
            {playerName}
          </h2>
        </div>

        <div className="perspective-1000 w-full aspect-[3/4] max-h-[400px]">
          <motion.div
            className="relative w-full h-full"
            animate={{ rotateY: isFlipped ? 180 : 0 }}
            transition={{ duration: 0.6, ease: "easeInOut" }}
            style={{ transformStyle: "preserve-3d" }}
          >
            <div
              className="absolute inset-0 backface-hidden rounded-xl bg-gradient-to-br from-primary/20 to-primary/5 border-2 border-primary/30 flex flex-col items-center justify-center cursor-pointer"
              onClick={() => setIsFlipped(true)}
              style={{ backfaceVisibility: "hidden" }}
              data-testid="card-front"
            >
              <div className="text-center space-y-4">
                <div className="w-20 h-20 rounded-full bg-primary/20 flex items-center justify-center mx-auto">
                  <EyeOff className="w-10 h-10 text-primary" />
                </div>
                <h3 className="text-2xl font-bold text-foreground">
                  {playerName}
                </h3>
                <p className="text-muted-foreground">Tap to reveal your role</p>
              </div>
            </div>

            <div
              className={`absolute inset-0 backface-hidden rounded-xl ${roleDisplay.bgColor} ${roleDisplay.textColor} flex flex-col items-center justify-center cursor-pointer`}
              onClick={() => setIsFlipped(false)}
              style={{ backfaceVisibility: "hidden", transform: "rotateY(180deg)" }}
              data-testid="card-back"
            >
              <div className="text-center space-y-4 p-6">
                <div className="w-16 h-16 rounded-full bg-white/20 flex items-center justify-center mx-auto">
                  <Eye className="w-8 h-8" />
                </div>
                <h3 className="text-3xl font-bold font-heading">
                  {roleDisplay.title}
                </h3>
                <p className="text-lg opacity-90">{roleDisplay.subtitle}</p>
                {roleDisplay.showNumber && (
                  <div className="mt-4">
                    <p className="text-sm opacity-75 mb-2">The number is</p>
                    <div className="w-24 h-24 rounded-full bg-white/20 flex items-center justify-center mx-auto">
                      <span className="text-5xl font-bold">{assignedNumber}</span>
                    </div>
                  </div>
                )}
                <p className="text-sm opacity-75 mt-4">Tap to hide</p>
              </div>
            </div>
          </motion.div>
        </div>

        <Button
          size="lg"
          className="w-full h-14 text-xl font-bold"
          onClick={onNextPlayer}
          data-testid="button-next-player"
        >
          {isLastPlayer ? "Start Discussion" : "Next Player"}
        </Button>
      </div>
    </div>
  );
}
