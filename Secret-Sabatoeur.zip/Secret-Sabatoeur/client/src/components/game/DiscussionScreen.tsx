import { Button } from "@/components/ui/button";
import PromptScale from "./PromptScale";
import { MessageCircle, ArrowRight } from "lucide-react";

interface DiscussionScreenProps {
  prompt: {
    title: string;
    lowLabel: string;
    highLabel: string;
  };
  onContinueToGuess: () => void;
}

export default function DiscussionScreen({
  prompt,
  onContinueToGuess,
}: DiscussionScreenProps) {
  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center px-4 py-8">
      <div className="w-full max-w-lg space-y-8">
        <div className="text-center space-y-2">
          <div className="w-16 h-16 rounded-full bg-primary/20 flex items-center justify-center mx-auto">
            <MessageCircle className="w-8 h-8 text-primary" />
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-foreground font-heading">
            Discussion Time
          </h1>
          <p className="text-muted-foreground text-lg">
            Each player gives an answer that matches their number on the scale
          </p>
        </div>

        <PromptScale
          title={prompt.title}
          lowLabel={prompt.lowLabel}
          highLabel={prompt.highLabel}
        />

        <div className="bg-primary/10 rounded-lg p-4 text-center">
          <p className="text-foreground font-medium">
            The Guesser listens to everyone&apos;s answers and tries to figure out the number.
            <br />
            <span className="text-muted-foreground text-sm">
              Watch out for the Saboteur giving misleading answers!
            </span>
          </p>
        </div>

        <Button
          size="lg"
          className="w-full h-14 text-xl font-bold gap-2"
          onClick={onContinueToGuess}
          data-testid="button-continue-to-guess"
        >
          Continue to Guess
          <ArrowRight className="w-5 h-5" />
        </Button>
      </div>
    </div>
  );
}
