interface PromptScaleProps {
  title: string;
  lowLabel: string;
  highLabel: string;
  highlightNumber?: number;
}

export default function PromptScale({
  title,
  lowLabel,
  highLabel,
  highlightNumber,
}: PromptScaleProps) {
  return (
    <div className="w-full space-y-4">
      <h2 className="text-2xl md:text-3xl font-bold text-foreground text-center font-heading">
        {title}
      </h2>
      
      <div className="bg-card rounded-lg p-4 md:p-6 border border-border">
        <div className="flex items-center gap-1">
          {Array.from({ length: 10 }, (_, i) => i + 1).map((num) => (
            <div
              key={num}
              className={`flex-1 h-8 md:h-10 flex items-center justify-center text-sm md:text-base font-semibold rounded-sm transition-all ${
                highlightNumber === num
                  ? "bg-primary text-primary-foreground ring-2 ring-primary ring-offset-2"
                  : "bg-gradient-to-r from-primary/10 to-primary/30"
              }`}
              style={{
                backgroundColor: highlightNumber === num 
                  ? undefined 
                  : `hsl(187, 100%, ${85 - (num - 1) * 5}%)`,
              }}
            >
              {num}
            </div>
          ))}
        </div>
        
        <div className="flex justify-between mt-3 text-sm md:text-base">
          <div className="text-left">
            <span className="font-bold text-foreground">1</span>
            <p className="text-muted-foreground uppercase text-xs md:text-sm">{lowLabel}</p>
          </div>
          <div className="text-right">
            <span className="font-bold text-foreground">10</span>
            <p className="text-muted-foreground uppercase text-xs md:text-sm">{highLabel}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
