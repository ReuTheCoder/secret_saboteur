# Design Guidelines: Social Deduction Party Game

## Design Approach
**Reference-Based**: Inspired by Rabble's "Bot or Not" and Jackbox Party Pack games - playful, high-contrast interfaces optimized for shared-screen viewing with bold, readable elements from across the room.

## Core Design Principles
1. **High Readability**: Large text and buttons visible from distance during group play
2. **Playful Energy**: Animated transitions and card flips create excitement
3. **Clear State Transitions**: Each game phase has distinct visual treatment
4. **Touch-First**: Large tap targets for easy device passing

## Color System (User-Specified)
- **Primary**: #00BCD4 (cyan blue) - main actions, headers
- **Secondary**: #000000 (black) - strong contrast elements
- **Background**: #FFFFFF (white) - clean canvas
- **Accent**: #0097A7 (dark cyan) - hover states, emphasis
- **Text**: #212121 (near black) - body text
- **Highlights**: #B2EBF2 (light cyan) - backgrounds, cards

## Typography
- **Primary Font**: Poppins (headings, buttons, game states)
- **Secondary Font**: Montserrat (body text, descriptions)
- **Scale**: 
  - Game titles: 48-64px bold
  - Player names/roles: 32-40px semibold
  - Button text: 24-28px bold
  - Body text: 18-20px regular
  - Mobile scales down 20-30%

## Layout System
**Spacing Units**: Tailwind 4, 6, 8, 12, 16, 24 for consistent rhythm
- Screen padding: px-4 md:px-8
- Card padding: p-6 md:p-8
- Button spacing: py-4 px-8
- Vertical sections: space-y-8 md:space-y-12

## Component Library

### Game Lobby
- Centered layout with max-w-2xl container
- Large title with cyan accent underline
- Player count selector: grid of numbered buttons (3-10), cyan background for selected state
- Prominent "Start Game" button at bottom

### Role Assignment Flashcards
- Card-based 3D flip animation (transform rotateY)
- **Front**: Player name (e.g., "Player 1") centered, light cyan background
- **Back**: Role reveal with number display for Teammates/Saboteur, "GUESSER" text for Guesser, black background with cyan text
- "Tap to Reveal" hint on front
- "Next Player" button appears after flip, fixed at bottom

### Prompt Display Screen
- Match reference image style: prompt text at top in large bold font
- Scale visualization: horizontal 1-10 number line with labels at endpoints
- Descriptive text explaining scale (e.g., "1 = Worst in a Fight, 10 = Best in a Fight")
- Current assigned number displayed prominently in cyan circle/badge
- "Continue to Guesser" button when ready

### Guesser Selection Interface
- Prompt displayed at top in bold 32px text
- Grid layout: 2 columns x 5 rows of number buttons (1-10)
- Each button: large square/rounded rectangle, minimum 80px height
- Cyan border on hover, filled cyan on selection
- "Submit Guess" button activates after selection

### Results Screen
- Centered reveal card with dramatic appearance animation
- "The Number Was: [X]" in 48px bold
- "The Saboteur Was: Player [Y]" with highlight
- Visual separation between sections
- "Play Again" button in cyan, "New Game" in outlined style

## Animations
- **Card Flips**: 0.6s ease-in-out 3D rotation
- **Screen Transitions**: 0.3s fade + slight slide
- **Button Interactions**: 0.2s scale on press (95%)
- **Number Reveal**: Staggered fade-in on results screen

## Responsive Behavior
- **Mobile (< 768px)**: Single column, full-width cards, larger tap targets
- **Desktop/Tablet**: Max-width containers (max-w-2xl to max-w-4xl), centered layouts
- Always maintain minimum 44px touch targets

## Images
No hero images required - this is a full-screen game interface. Use solid color backgrounds with geometric accents (optional cyan gradient overlays or subtle patterns) to maintain high contrast and readability.